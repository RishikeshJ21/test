import React, { lazy, Suspense } from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './globals.css';
import { PerformanceProvider } from './Components/PerformenceProvider';

// Register service worker for PWA capabilities
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .catch(error => {
                console.log('SW registration failed:', error);
            });
    });
}

// Optimize font loading
const fontStylesheet = document.createElement('link');
fontStylesheet.rel = 'stylesheet';
fontStylesheet.href = '/fonts/font-stylesheet.css';
fontStylesheet.media = 'print';
fontStylesheet.onload = () => {
    fontStylesheet.media = 'all';
};
document.head.appendChild(fontStylesheet);

// Use a lightweight loading component
const LoadingFallback = () => <div className="flex items-center justify-center h-screen">Loading...</div>;

// Lazy load the App component
const App = lazy(() => import('./App'));

ReactDOM.createRoot(document.getElementById('root')!).render(

        <PerformanceProvider>
            <BrowserRouter>
                <Suspense fallback={<LoadingFallback />}>
                    <App />
                </Suspense>
            </BrowserRouter>
        </PerformanceProvider>
    
);