 
export const people = [
  {
    id: 1,
    name: "Arjun Patel",
    designation: "Software Engineer",
    image:
      "/trustedby200creators/3.avif",
  },
  {
    id: 2,
    name: "Vikram Sharma",
    designation: "Product Manager",
    image:
      "/trustedby200creators/2.avif",
  },
  {
    id: 3,
    name: "Priya Mehta",
    designation: "Data Scientist",
    image:
      "/trustedby200creators/1.avif",
  },
  {
    id: 4,
    name: "Neha Gupta",
    designation: "UX Designer",
    image:
      "/trustedby200creators/5.avif",
  },
  {
    id: 5,
    name: "Raj Malhotra",
    designation: "Content Creator",
    image:
      "/trustedby200creators/4.avif",
  },
  {
    id: 6,
    name: "Ananya Singh",
    designation: "Digital Marketer",
    image:
      "https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3534&q=80",
  },
];